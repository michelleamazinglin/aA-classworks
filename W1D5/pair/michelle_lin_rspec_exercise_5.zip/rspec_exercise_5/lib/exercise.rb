def zip(*arr)
  arr.transpose
end

# def zip(*arr)#[['a', 'b', 'c'], [1, 2, 3]]
#     length = arr.first.length
#     subArr_length = arr.length
#   new_arr = Array.new(length){}
#   arr.each do |sub_arr|
#     i = 0
#     new_sub_arr = []
#     while i < sub_arr.length
#       new_sub_arr << sub_arr[i]
#       i += 1
#     end
#     new_arr << new_sub_arr 
#   end
#   new_arr
# end

# def zip(*arr)
#   matrix = arr.first
#   height = arr.length
#   width = arr[0].length

#   empty_arr = Array.new(height) { [0] * width }
#   arr.inject(empty_arr) do |m1, m2|
#       matrix_addition(m1, m2)
#   end
# end


# def matrix_addition(m1, m2)
#     height = m1.length
#     width = m1[0].length
#     result = Array.new(height) { [0] * width }

#     (0...height).each do |row|
#         (0...width).each do |col|
#             result[row][col] = m1[row][col] + m2[row][col]
#         end
#     end

#     result
# end

def prizz_proc(arr, prc1, prc2)
  arr.select { |ele| prc1.call(ele) != prc2.call(ele) }
end

# def zany_zip(*arr)
# #   length = []
# #   width = []
# #   arr.each do |sub_arr|
# #     length << sub_arr.length
# #     sub_arr.each do |num|
# #         width << num.length
# #     end
# #   end
# #   max_length = length.max
# #   max_width = width.max
#     col = arr.length
#     row_count = []
#     arr.each do |subArr|
#       row_count << subArr.length
#       row = row.max
#     end
#     new_arr = Array.new(row) { Array.new(col) }

#     new_arr = arr.transpose
# end

# empty_table = Array.new(3) { Array.new(3) }
# #=> [[nil, nil, nil], [nil, nil, nil], [nil, nil, nil]]
# array_1 = ['a', 'b', 'c']
# array_2 = [1, 2, 3] 
# p zany_zip(array_1, array_2)

# p arr = [["a","b","c"],[1,2,3]]
# p arr.zip
# p arr.zip.transpose

# [["a", "b", "c"], [1, 2, 3]]
# [[["a", "b", "c"]], [[1, 2, 3]]]
# [[["a", "b", "c"], [1, 2, 3]]]

# p arr = [["a","b","c"],[1,2,3]]
# p arr.transpose.zip

# [["a", "b", "c"], [1, 2, 3]]
# [[["a", 1]], [["b", 2]], [["c", 3]]]

# def zany_zip(*arr) #["a", "b", "c"], [1, 2, 3]
#   length = []
#   arr.each do |sub_arr|
#     length << sub_arr.length 
#   end
#   max_length = length.max # 3

# #   (0...max_length).each do |i| # 1 (["a", "b", "c"]),2  ([1, 2, 3])
    

# end

def maximum(arr, &prc)
  return nil if arr.length == 0
  arr.inject do |accum, el|
    if prc.call(accum) <= prc.call(el)
        el
    else 
        accum
    end
  end
end
# p maximum([2, 4, -5, 1]) { |n| n * n } #-5


def my_group_by(arr, &prc)
    hash = Hash.new {|h, k| h[k] = []} #default
    arr.each do |ele|
        hash[prc.call(ele)] << ele # arr
    end
    hash
end

def max_tie_breaker(arr, prc1, &prc2)
  arr.inject do |accum, el|
    if prc2.call(accum) < prc2.call(el)
      el
    elsif prc2.call(accum) == prc2.call(el)
      if prc1.call(accum) < prc1.call(el)
        el
      else
        accum
      end     
    else 
    accum
    end
  end
end

def silly_syllables(sent)
  sent.split.map { |word| removed_vowel(word) }.join(" ")
end

def removed_vowel(word)
  vowels = "aeiou"
  idx_of_vowels = []
  new_word = ""
  
  word.each_char.with_index do |char, i|
    if vowels.include?(char)
      idx_of_vowels << i
    end
  end

  first_vowel_idx = idx_of_vowels.first
  last_vowel_idx = idx_of_vowels.last
#   p idx_of_vowels
#   p first_vowel_idx
#   p last_vowel_idx

  if idx_of_vowels.length < 2 || idx_of_vowels.length == nil
    new_word += word
  else
    new_word += word[first_vowel_idx..last_vowel_idx] 
  end
  new_word 
#   p new_word

end

# def removed_vowel(word) #banan
#     vowel = "aeiou"
#     new_word = ""
#     inter_word = ""
#     count = 0
#     word.each_char do |char|
#         if vowel.include?(char)
#             count += 1
#         end
#     end

#     if count < 2
#         new_word += word
#     else
#         word.each_char.with_index do |char, i| #char = a
#             if vowel.include?(char) # a
#                 inter_word += word[i..-1] # nw = anana
#             end
#         end
  
#         inter_word.each_char do |char|
#             i = -1    
#             while i > (-word.length)
#                 if vowel.include?(char)
#                     new_word += inter_word[0..i]
#                 end
#                 i -= 1
#             end 
#         end
#     end
#   new_word
# # end

# p silly_syllables('the trashcans collect all my garbage') #'the ashca olle all my arbage'
